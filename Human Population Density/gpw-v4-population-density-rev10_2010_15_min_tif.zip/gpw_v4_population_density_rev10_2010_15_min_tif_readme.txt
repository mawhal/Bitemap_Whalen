documentation: http://sedac.ciesin.columbia.edu/downloads/docs/gpw-v4/gpw-v4-documentation.pdf

website: http://sedac.ciesin.columbia.edu/data/collection/gpw-v4/sets/browse